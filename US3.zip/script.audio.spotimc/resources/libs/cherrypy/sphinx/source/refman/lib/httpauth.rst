****************************
:mod:`cherrypy.lib.httpauth`
****************************

.. automodule:: cherrypy.lib.httpauth

Functions
=========

.. autofunction:: calculateNonce

.. autofunction:: digestAuth

.. autofunction:: basicAuth

.. autofunction:: doAuth

.. autofunction:: parseAuthorization

.. autofunction:: md5SessionKey

.. autofunction:: checkResponse

