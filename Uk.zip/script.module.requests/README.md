script.module.requests
======================

Python requests library packed for XBMC.

See https://github.com/kennethreitz/requests
