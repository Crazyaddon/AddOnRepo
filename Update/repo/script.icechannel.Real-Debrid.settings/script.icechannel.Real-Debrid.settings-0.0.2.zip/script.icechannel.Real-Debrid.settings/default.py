addon_id="script.icechannel.Real-Debrid.settings"
addon_name="iStream - Real-Debrid - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
