addon_id="script.icechannel.superchillin.settings"
addon_name="iStream - superchillin - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
