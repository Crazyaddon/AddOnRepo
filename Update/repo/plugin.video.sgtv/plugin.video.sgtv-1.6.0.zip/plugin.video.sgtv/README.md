plugin.video.sgtv
=================

An XBMC/Kodi Addon for Singapore TV (Mediacorp 5/8, Channel U, CNA, Vasantham, Suria, ViddSee, WahBanana)

SG!TV was first released on 2012 Sep 03 - http://www.gadgetreactor.com/portfolio/sgtv/ primarily for myself to catch
up on local Mediacorp (Singapore) shows. 

It is now published on Github.

Sean Seah
GadgetReactor

=================
Changelog
=================

V1.6.0 - 2015-07-10
Updated changes for new Toggle Page
For sections Newest, Channel 5, Channel 8, Suria, Vasantham, Channel U
Updated playback mechanism
VIP Subscriber access videos ignored

V1.5.5 - 2015-03-11
Updated regular expressions to cope with website changes

V1.5.1 - 2014-11-17
Updated revision numbering
Updated Addon.xml 
Updated icon
Remove untranslatable text used in dialogs

V1.5.0 - 2014-10-23
Major changes to the backend
- New parsing logic
- Ability to load thumbnails
New channels, CNA, WahBanana, ViddSee

V1.4.0 (Internal)

V1.3.0 - 2014-10-14
Interim fixes
Accomodate changes to new website backend on xinmsn / catchup tv

V1.2.0 (Internal)

V1.1.0 - 2012-12-04
Bugfixes
V1.0.0 - 2012-09-03
First public release
