addon_id="script.icechannel.Vidup.me.settings"
addon_name="iStream - Vidup.me - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
