addon_id="script.icechannel.Videowood.settings"
addon_name="iStream - Videowood - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
