
class Handler(object):
    def handle_GetVariable(self, msg):

