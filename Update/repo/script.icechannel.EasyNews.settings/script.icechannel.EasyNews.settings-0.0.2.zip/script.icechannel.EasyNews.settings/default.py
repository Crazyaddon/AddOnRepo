addon_id="script.icechannel.EasyNews.settings"
addon_name="iStream - EasyNews - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
