addon_id="script.icechannel.Filehoot.settings"
addon_name="iStream - Filehoot - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
