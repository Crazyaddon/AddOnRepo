addon_id="script.icechannel.iStream.tv_shows.settings"
addon_name="iStream - TV Shows - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
