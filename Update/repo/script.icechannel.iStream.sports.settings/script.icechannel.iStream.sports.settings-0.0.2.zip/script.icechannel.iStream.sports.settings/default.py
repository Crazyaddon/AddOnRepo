addon_id="script.icechannel.iStream.sports.settings"
addon_name="iStream - Sports (Live) - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
