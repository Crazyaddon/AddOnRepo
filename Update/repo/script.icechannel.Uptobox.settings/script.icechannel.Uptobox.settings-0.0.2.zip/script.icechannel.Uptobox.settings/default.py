addon_id="script.icechannel.Uptobox.settings"
addon_name="iStream - Uptobox - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
