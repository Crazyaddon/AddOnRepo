addon_id="script.icechannel.Realvid.settings"
addon_name="iStream - Realvid - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
