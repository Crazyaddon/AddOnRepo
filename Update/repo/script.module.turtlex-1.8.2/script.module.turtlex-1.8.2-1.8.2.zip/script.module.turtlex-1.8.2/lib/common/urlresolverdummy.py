

def choose_source(sources):
    pass

def display_settings():
    pass

def filter_source_list(source_list):
    pass

def resolve(web_url):
    pass

class HostedMediaFile:
    
    def __init__(self, url='', host='', media_id='', title=''):
        return None
    
    def get_host(self):
        return None
    
    def get_media_id(self):
        return None
    
    def get_url(self):
        return None
    
    def resolve(self):
        return None
    
    def valid_url(self):
        return None
    
    
