addon_id="script.icechannel.theme.xunityhd"
addon_name="iStream Theme - Xunity HD"