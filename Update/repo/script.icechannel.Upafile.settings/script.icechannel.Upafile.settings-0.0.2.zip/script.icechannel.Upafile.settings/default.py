addon_id="script.icechannel.Upafile.settings"
addon_name="iStream - Upafile - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
