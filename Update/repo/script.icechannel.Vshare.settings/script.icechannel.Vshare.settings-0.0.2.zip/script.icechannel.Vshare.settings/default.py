addon_id="script.icechannel.Vshare.settings"
addon_name="iStream - Vshare - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
