import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys,os,urllib

import urlresolver
    

addonID = 'plugin.video.tv-release'
local = xbmcaddon.Addon(id=addonID)

sys.path.append( os.path.join( local.getAddonInfo('path'),'resources','lib'))
art = xbmc.translatePath(os.path.join( local.getAddonInfo('path'),'resources','art'))
baseUrl = 'http://tv-release.net/'

try:
    try:
        from addon.common.addon import Addon
    except:
        raise Exception ('Addon.common Not Found')
    try:
        from metahandler import metahandlers
    except:
        raise Exception ('Module Metahandler Not Found')
    from t0mm0.common.net import Net
    
except Exception, e:
    xbmc.log('TV-Release ERROR: '+str(e))
    dialog = xbmcgui.Dialog()
    dialog.ok('[COLOR red]Failed To Find Needed Modules[/COLOR]','[COLOR red][B]'+str(e)+'[/COLOR][/B]',
              'Please Goto [COLOR green][B]XBMCTALK.COM[/COLOR][/B] For Support')
    xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=True)

grab = metahandlers.MetaData()
Addon = Addon(addonID, sys.argv)
net = Net()

def Main():
    addDir(100,baseUrl,None,None,'[COLOR blue][B]This Works Best With A Real Debrid Account[/COLOR][/B]',
           os.path.join(art,'info.png'),0,'',False)
    addDir(100,baseUrl+'?cat=TV-480p',None,None,'TV - 480p [COLOR red][B]*HD*[/COLOR][/B]',
           os.path.join(art,'480P.png'),0,'',True)
    addDir(100,baseUrl+'?cat=TV-720p',None,None,'TV - 720p [COLOR red][B]*HD*[/COLOR][/B]',
           os.path.join(art,'720P.png'),0,'',True)
    addDir(100,baseUrl+'?cat=TV-Mp4',None,None,'TV  - MP4',
           os.path.join(art,'mp4.png'),0,'',True)
    addDir(100,baseUrl+'?cat=TV-XviD',None,None,'TV - Xvid',
           os.path.join(art,'xvid.png'),0,'',True)
    addDir(300,baseUrl,None,None,'[COLOR yellow]Urlresolver Settings[/COLOR]',
           os.path.join(art,'urlresolver.png'),0,'',False)


def findHosts(url,name,ilstr):
    xbmc.executebuiltin("XBMC.Notification(TV-Release Finding Sources,,"+os.path.join(art,'hosts.jpg')+",4000,'')")
    
    import re

    #html = requests.get(url)

    html = net.http_GET(url).content
    totalItems = 0
    sources = []

    for item in re.finditer(r'blank\'\shref=\'(http.*?)\'\>',
                            html):
        hoster = re.search(r'//(.*?)/',item.group(1)).group(1).replace('www.','')
        sources.append(urlresolver.HostedMediaFile(url=item.group(1),title=hoster))

    for item in re.finditer(r'\n(http.*?)\n\<',html,re.DOTALL):
        hoster = re.search(r'//(.*?)/',item.group(1)).group(1).replace('www.','')
        sources.append(urlresolver.HostedMediaFile(url=item.group(1).replace('\r',''),title=hoster))

    source = urlresolver.choose_source(sources)
    if source:
        stream_url = source.resolve()
        xbmc.Player().play(stream_url)


     
def findMedia(url):
    import re

    #html = requests.get(url)

    html = net.http_GET(url).content
    for item in re.finditer(r'bold\;\'\>\<a href=\'(.*?\d+\/.*?)\'\>(.*?)\<',html,re.I):
        name = cleanName(item.group(2))
        addDir(200,item.group(1),'episode',name,name,'',0,'',False)

    

    if re.search(r'class=\'zmg_pn_current\'\>\d+\<',html,re.I):
        for item in re.finditer(r'class=\'zmg_pn_current\'\>(\d+)\<\/.*?class=\'zmg_pn_standar\'><a href=\".*?(index\.php.*?cat.*?)\"\>\d+',
                                html,re.I):
            np = baseUrl+item.group(2).replace('&','%26')
            name = '[B][COLOR royalblue]Current Page: '+item.group(1)+', Next Page>>[/COLOR][/B]'
            addDir(100,np,None,None,name,'',0,'',True)
            
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    xbmc.executebuiltin("Container.SetViewMode(59)")


def GRABMETA(metaType,metaName):
    import re

    if metaType == None:
        return

    tvshowtitle = ''
    imdb_id = ''
    season = ''
    episode = ''
    air_date = ''
    episode_title = ''
    metaName = metaName +':'

    
    if re.search(r'\s\d{4}\s\d{2}\s\d{2}\s',metaName):
        pattern = '(.*?)\s(\d+\s\d+\s\d+)\s([\D\s_]+)'
        for items in re.finditer(r''+pattern+'',metaName):
            infoLabels = {'cover_url': '','title': metaName}
            tvshowtitle = items.group(1)
            air_date = items.group(2).strip().replace(' ','-')
            episode_title = items.group(3)
            

    elif re.search(r'\sS\d+E\d+\s',metaName):
        pattern = '(.*?)\sS(\d+)E(\d+)([\D\s_]+)'
        for items in re.finditer(r''+pattern+'',metaName,re.I):
            tvshowtitle = items.group(1)
            season = items.group(2)
            episode = items.group(3)
            episode_title = items.group(4)

    elif re.search(r'\sS\d+E\d+:',metaName):
        pattern = '(.*?)\sS(\d+)E(\d+):'
        for items in re.finditer(r''+pattern+'',metaName,re.I):
            tvshowtitle = items.group(1)
            season = items.group(2)
            episode = items.group(3)
            
    if metaType == 'episode':
        if air_date != '':
            episode = '0'
        if re.search('\sand\s', metaName):
            tvshowtitle = tvshowtitle.replace(r'and','&')
        infoLabels = grab.get_meta('tvshow', tvshowtitle, imdb_id='', tmdb_id='', year='', overlay=6)
        
    return infoLabels

def cleanName(name):
    import re
    if re.search('\d+p', name):
        name = re.search(r'(.*?)\d+p', name).group(1)
    elif re.search('\sHDTV\s',name):
        name = re.search(r'(.*?)\sHDTV\s',name).group(1)
    return name
                 

def addDir(mode,url,metaType,metaName,name,icon,totalItems,ilstr,folder):
    u = sys.argv[0]
    u += "?mode=" +str(mode)
    u += "&url=" +str(url)
    u += "&metaType=" +str(metaType)
    u += "&metaName=" +str(metaName)
    u += "&name=" +str(name)
    u += "&icon=" +str(icon)
    u += "&totalItems=" +str(totalItems)
    u += "&ilstr=" +str(ilstr)
    u += "&folder=" +str(folder)

    

    if local.getSetting("usemeta") == "true" and metaType != 'None':
        infoLabels = GRABMETA(metaType,metaName)

     
    else:
        infoLabels = {'cover_url': "", 'title': name}
    
    if metaType == None:
        img = icon
    else:
        img = infoLabels['cover_url']

    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
    try:
        if infoLabels['backdrop_url'] == '':
            infoLabels['backdrop_url'] = xbmc.translatePath(os.path.join(local.getAddonInfo('path'),'fanart.jpg'))
        liz.setProperty('fanart_image', infoLabels['backdrop_url'])

   
    except:
        liz.setProperty('fanart_image', xbmc.translatePath(os.path.join(
            local.getAddonInfo('path'),'fanart.jpg')))
        pass

    liz.setInfo( type="Video", infoLabels = infoLabels )
    if folder == True:ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,
                                                     totalItems=int(totalItems))
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
mode = None
url = None
metaType = None
metaName = None
name = None
icon = None
totalItems = None
ilstr = None
folder = None

try:
    mode = urllib.unquote_plus(params['mode'])
except:
    pass
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    metaType = urllib.unquote_plus(params["metaType"])
except:
    pass
try:
    metaName = urllib.unquote_plus(params["metaName"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    icon = urllib.unquote_plus(params["icon"])
except:
    pass
try:
    totalItems = urllib.unquote_plus(params['totalItems'])
except:
    pass
try:
    ilstr = urllib.unquote_plus(params['ilstr'])
except:
    pass
try:
    folder = urllib.unquote_plus(params["folder"])
except:
    pass


xbmc.log('Mode: '+str(mode))
xbmc.log('Url: '+str(url))
xbmc.log('metaType: '+str(metaType))
xbmc.log('metaName: '+str(metaName))
xbmc.log('Name: '+str(name))
xbmc.log('Icon: '+str(icon))
xbmc.log('TotalItems: '+str(totalItems))
xbmc.log('Folder: '+str(folder))

if mode == None or url == None or len(url)<1:
    Main()
elif mode == '100':
    findMedia(url)
elif mode == '200':
    findHosts(url,name,ilstr)
elif mode == '300':
    urlresolver.display_settings()
        
xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=True)
