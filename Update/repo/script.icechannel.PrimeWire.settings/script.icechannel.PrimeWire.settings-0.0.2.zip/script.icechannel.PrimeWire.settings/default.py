addon_id="script.icechannel.PrimeWire.settings"
addon_name="iStream - PrimeWire - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
