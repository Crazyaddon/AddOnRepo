Wiener Linien XBMC Addon
=======


Requirements
------------
Tested on XBMC Frodo


Supported platforms
-------------------
Windows, Linux , Android and OSX


Current Features
----------------
* Access Live data from open.wien.at
* List Stations
* Search by Stations
* Favourites
* Show Failures