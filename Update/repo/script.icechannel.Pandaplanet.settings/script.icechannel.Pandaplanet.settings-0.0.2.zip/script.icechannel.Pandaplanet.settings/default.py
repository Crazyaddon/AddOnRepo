addon_id="script.icechannel.Pandaplanet.settings"
addon_name="iStream - Pandaplanet - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
