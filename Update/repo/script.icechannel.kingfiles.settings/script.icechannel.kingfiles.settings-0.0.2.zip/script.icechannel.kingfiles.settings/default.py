addon_id="script.icechannel.kingfiles.settings"
addon_name="iStream - kingfiles - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
