addon_id="script.icechannel.Mrfile.settings"
addon_name="iStream - Mrfile - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
