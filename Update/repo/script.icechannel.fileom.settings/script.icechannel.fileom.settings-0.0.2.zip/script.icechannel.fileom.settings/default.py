addon_id="script.icechannel.fileom.settings"
addon_name="iStream - fileom - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
