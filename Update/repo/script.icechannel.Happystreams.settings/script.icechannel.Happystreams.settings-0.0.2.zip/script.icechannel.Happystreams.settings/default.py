addon_id="script.icechannel.Happystreams.settings"
addon_name="iStream - Happystreams - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
