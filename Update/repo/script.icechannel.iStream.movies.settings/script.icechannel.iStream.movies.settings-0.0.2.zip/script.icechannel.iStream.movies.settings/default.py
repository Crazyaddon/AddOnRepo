addon_id="script.icechannel.iStream.movies.settings"
addon_name="iStream - Movies - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
