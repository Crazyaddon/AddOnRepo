addon_id="script.icechannel.Mightyupload.settings"
addon_name="iStream - Mightyupload - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
