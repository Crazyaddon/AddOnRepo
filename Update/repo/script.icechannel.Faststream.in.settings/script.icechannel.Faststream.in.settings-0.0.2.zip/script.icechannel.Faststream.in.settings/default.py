addon_id="script.icechannel.Faststream.in.settings"
addon_name="iStream - Faststream.in - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
