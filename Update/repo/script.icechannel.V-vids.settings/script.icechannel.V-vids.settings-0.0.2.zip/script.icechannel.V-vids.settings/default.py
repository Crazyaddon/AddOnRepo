addon_id="script.icechannel.V-vids.settings"
addon_name="iStream - V-vids - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
