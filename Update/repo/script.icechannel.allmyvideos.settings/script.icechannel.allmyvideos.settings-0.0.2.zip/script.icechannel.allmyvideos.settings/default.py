addon_id="script.icechannel.allmyvideos.settings"
addon_name="iStream - allmyvideos - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
