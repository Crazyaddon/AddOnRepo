addon_id="script.icechannel.FILMON.COM.settings"
addon_name="iStream - FILMON.COM - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
