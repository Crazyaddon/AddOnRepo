# TheXEM.de XBMC Scraper #

This XBMC TV Scraper uses the TheXEM.de proxy service to map 'scene' episode numbering to their TheTVDB.com counterparts. 

For more information on the XEM project please visit http://www.TheXEM.de.
