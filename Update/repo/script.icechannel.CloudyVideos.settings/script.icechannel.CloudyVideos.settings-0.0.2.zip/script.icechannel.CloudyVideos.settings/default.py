addon_id="script.icechannel.CloudyVideos.settings"
addon_name="iStream - CloudyVideos - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
