![](https://raw.githubusercontent.com/bromix/repository.bromix.storage/master/plugin.video.9gagtv/icon.png)
# **Links:**

* [9GAG.TV](www.9gag.tv)

[![](https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif)](https://goo.gl/U5oVOj) [![](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://goo.gl/15V9TN) [![](https://www.paypalobjects.com/de_DE/i/btn/btn_donate_LG.gif)](https://goo.gl/oEjE9E) [![](https://pledgie.com/campaigns/29261.png?skin_name=chrome)](https://goo.gl/K4RZrZ) 

# **Changelog:**

## **3.0.1**

* support of direct video URLs

## **3.0.0**

* framework

## **2.0.1**

* playback of vimeo videos
* kodion


