plugin.video.foodnetwork================

Kodi Addon for Food Network website

Version 2.1.11 added subtitles, metadata, views
Version 2.1.10 website changes
Version 2.1.9 website changes
Version 2.1.8 website changes
Version 2.1.7 website changes
Version 2.1.5 website changes
version 2.1.4 website changes
version 2.1.3 website changes
version 2.1.2 website changes
version 2.0.2 initial release

