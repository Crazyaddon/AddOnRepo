addon_id="script.icechannel.noobroom.settings"
addon_name="iStream - noobroom - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
