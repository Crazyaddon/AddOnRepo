addon_id="script.icechannel.TheVideo.settings"
addon_name="iStream - TheVideo - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
