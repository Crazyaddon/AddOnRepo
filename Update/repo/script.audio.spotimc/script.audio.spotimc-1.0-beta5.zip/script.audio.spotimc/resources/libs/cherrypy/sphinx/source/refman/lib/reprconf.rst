****************************
:mod:`cherrypy.lib.reprconf`
****************************

.. automodule:: cherrypy.lib.reprconf

Classes
=======

.. autoclass:: NamespaceSet
   :members:

.. autoclass:: Config
   :members:

.. autoclass:: Parser
   :members:

Functions
=========

.. autofunction:: as_dict

.. autofunction:: unrepr

.. autofunction:: modules

.. autofunction:: attributes

