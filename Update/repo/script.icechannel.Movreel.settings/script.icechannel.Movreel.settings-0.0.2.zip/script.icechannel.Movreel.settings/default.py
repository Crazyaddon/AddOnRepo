addon_id="script.icechannel.Movreel.settings"
addon_name="iStream - Movreel - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
