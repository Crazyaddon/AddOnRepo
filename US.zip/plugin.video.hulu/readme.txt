::CREDIT::
All icons and fanart created by SamHill from XBMC forums