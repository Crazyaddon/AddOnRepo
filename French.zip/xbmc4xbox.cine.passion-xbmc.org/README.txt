Scraper Ciné-Passion for XBMC4XBox

Copy folder "\xbmc4xbox.cine.passion-xbmc.org\scrapers"
to folder "Q:\system\scrapers" and overwrite existing files.

OR

1. UNZIP xbmc4xbox.cine.passion-xbmc.org-x.x.x.zip to Q:\\scripts\xbmc4xbox.cine.passion-xbmc.org
2. AND RENAME Q:\\scripts\xbmc4xbox.cine.passion-xbmc.org to Q:\\scripts\Cine-Passion Scraper Update
3. And Run Updater to Window Scripts ;)
